const fs = require("fs");
const input = fs.readFileSync("input.txt").toString().trim();

let N = input[0]; 

let A = N.split('')

if(A<10){
    A.unshift('0');
}

let NL = A[0];    // N의 가장 왼쪽 자리 수 NL
let NR = A[1];    // N의 가장 오른쪽 자리 수 NR

let temp = parseInt(NL)+parseInt(NR); // 정수로 변경된 각 자리의 숫자(NL,NR) 더한 결과

let B = temp.toString().split('');

if(B<10){
    B.unshift('0');
}

let tL = B[0];  // temp의 가장 왼쪽 자리 수 tL
let tR = B[1];  // temp의 가장 오른쪽 자리 수 tR

N = NR + tR;
console.log(N);

// let C = result.toString().split('');

