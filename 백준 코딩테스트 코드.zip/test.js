/* let A = parseInt(input[0].split(' ')[0]);
let B = parseInt(input[0].split(' ')[1]);
let a = input[1].split(' '); */



const fs = require("fs");
const input = fs.readFileSync("input.txt").toString().trim().split('\n');

let N = input[0]; // .split('')로 입력된 수를 쪼개줌

let A = N.split('')

// N < 10 이면 앞에 문자 0 붙여주는 기능
if(N<10){
    N.unshift('0');
}

// 각 자리의 숫자 정수형으로 변경
let NL = N[0];    // N의 가장 왼쪽 자리 수 NL
let NR = N[1];    // N의 가장 오른쪽 자리 수 NR

let temp = parseInt(NL)+parseInt(NR); // 정수로 변경된 각 자리의 숫자(NL,NR) 더한 결과

// temp 를 문자형으로 변환하고 쪼갬
let B = temp.toString().split('');

// temp가 문자형으로 변환된 A < 10 이면 앞에 0 붙여주는 기능
if(B<10){
    B.unshift('0');
}

let tL = B[0];  // temp의 가장 왼쪽 자리 수 tL
let tR = B[1];  // temp의 가장 오른쪽 자리 수 tR

// NR + tR
let result = NR + tR;

// result 를 문자형으로 변환하고 쪼갬
let C = result.toString().split('');


// 위 과정을 반복 시켜주는 함수 N == B이면 종료
// but 반복된 횟수를 구하는 게 정답인데 조건식 설정을 어떻게 할까?
// 무한으로 돌려보고 마지막 i를 구하면 되지않을까?

/* for(let i=0; N == result; i++){
    // 대충 위에 과정 복사
    let j = i + 1;  // 사이클 길이j
    console.log(j);
} */
let i = 0;
while(1){
    
}

console.log(A);