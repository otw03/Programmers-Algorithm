const fs = require("fs");
const input = fs.readFileSync("input.txt").toString().trim();

let N = input[0];
console.log(N); // 8
let A = N.split('')
console.log(A); // [ '8' ]
if(A<10){   
    A.unshift('0');
}
console.log(A); // [ '0', '8' ]

let temp = parseInt(A[0])+parseInt(A[1]); // 정수로 변경된 각 자리의 숫자(NL,NR) 더한 결과
console.log(temp);  // 8
let B = temp.toString().split('');
console.log(B); // [ '8' ]
if(B<10){
    B.unshift('0');
}
console.log(B); // [ '0', '8' ]
N = A[1]+B[1];
// A = parseInt(B[0])+parseInt(B[1]);
console.log(N); // 88

// let C = result.toString().split('');

